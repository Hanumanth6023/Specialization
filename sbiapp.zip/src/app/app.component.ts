import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  employees:any =[];
  constructor(private user1:UserService){}

  ngOnInit(): void{

    this.user1.getAllEmp().subscribe( (data) =>{
      this.employees=data;
      console.log(data);
    })

  }
}
