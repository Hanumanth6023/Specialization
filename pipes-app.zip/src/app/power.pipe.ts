import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'power'
})
export class PowerPipe implements PipeTransform {

  transform(value: number, ...args: number[]): unknown {
    
    var result=value;

    for (let index = 1; index < args[0]; index++) {
         result =  result * value;
      
    }
    
    return result;
  }

}
