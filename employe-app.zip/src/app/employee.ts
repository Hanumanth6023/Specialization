export class Employee{
id:number=0;
name:string='';
city:string='';
}
