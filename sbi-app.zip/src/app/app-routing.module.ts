import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HelpComponent } from './help/help.component';
import { HomeComponent } from './home/home.component';
import { HouseloanComponent } from './houseloan/houseloan.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { VehicleloanComponent } from './vehicleloan/vehicleloan.component';

const routes: Routes = [
  {path:'' ,component:HomeComponent},
{path:'about' ,component:AboutComponent},
{path:'help' ,component:HelpComponent},
{path:'contact' ,component:ContactComponent},
{path:'login' ,component:LoginComponent},
{path:'register' ,component:RegisterComponent},
{path:'vehicleloan' ,component:VehicleloanComponent},
{path:'houseloan' ,component:HouseloanComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
